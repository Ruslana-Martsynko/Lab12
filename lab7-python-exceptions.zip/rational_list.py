from exceptions import RationalValueError
from rational import Rational

class RationalList:
    def __init__(self):
        self.items = []

    def add(self, rational):
        if not isinstance(rational, Rational):
            raise RationalValueError("Можна додавати лише об'єкти типу Rational")
        self.items.append(rational)

    def __str__(self):
        return ", ".join(str(item) for item in self.items)