from exceptions import RationalError

class Rational:
    def __init__(self, numerator, denominator):
        if denominator == 0:
            raise RationalError()
        self.numerator = numerator
        self.denominator = denominator

    def __str__(self):
        return f"{self.numerator}/{self.denominator}"