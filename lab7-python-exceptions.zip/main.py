from rational import Rational
from rational_list import RationalList
from exceptions import RationalError, RationalValueError

rl = RationalList()

try:
    r1 = Rational(1, 2)
    print(f"Додаємо {r1} до списку")
    rl.add(r1)
except RationalError as e:
    print("Помилка створення Rational:", e)

try:
    rl.add("текст")
except RationalValueError as e:
    print("Помилка:", e)

print("Поточний список:", rl)