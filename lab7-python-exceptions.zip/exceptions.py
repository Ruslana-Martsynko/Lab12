class RationalError(ZeroDivisionError):
    def __init__(self, message="Знаменник не може дорівнювати нулю"):
        super().__init__(message)

class RationalValueError(ValueError):
    def __init__(self, message="Неприпустиме значення для операції з Rational"):
        super().__init__(message)